package moe.chenxy.hyperpods.lsp;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * HyperPods AAP -> SystemUI bridge. Enable this module for BOTH
 * moe.chenxy.hyperpods and com.android.systemui in LSPosed.
 */
public final class HyperPodsHook implements IXposedHookLoadPackage {
    private static final String TARGET = "moe.chenxy.hyperpods";
    private static final String SYSTEM_UI = "com.android.systemui";
    private static final String ACTION = "moe.chenxy.hyperpods.lsp.SHOW_BATTERY_CARD";
    private static final String TAG = "[HyperPodsIslandLSP] ";
    private static final long CARD_DURATION_MS = 1500L;
    private static final long THROTTLE_MS = 450L;

    private static volatile Application targetApplication;
    private static volatile String lastBattery = "";
    private static volatile String lastEar = "";
    private static volatile boolean pendingWearPopup = false;
    private static volatile boolean previousWearing = false;
    private static final AtomicLong lastSent = new AtomicLong(0L);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile View activeCard;
    private static volatile WindowManager activeWindowManager;

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (TARGET.equals(lp.packageName)) {
            XposedBridge.log(TAG + "hooking HyperPods app process");
            hookTargetApplication(lp.classLoader);
            hookModel(lp.classLoader, "moe.chenxy.hyperpods.utils.data.BatteryParams", true);
            hookModel(lp.classLoader, "moe.chenxy.hyperpods.utils.data.PodBatteryParams", true);
            hookModel(lp.classLoader, "moe.chenxy.hyperpods.utils.data.EarDetectionParams", false);
            hookModel(lp.classLoader, "moe.chenxy.hyperpods.utils.data.StrongToastBean", true);
        } else if (SYSTEM_UI.equals(lp.packageName)) {
            XposedBridge.log(TAG + "hooking SystemUI process");
            hookSystemUi(lp.classLoader);
        }
    }

    private static void hookTargetApplication(ClassLoader loader) {
        try {
            XposedHelpers.findAndHookMethod(Application.class, "onCreate", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Application app = (Application) p.thisObject;
                    if (TARGET.equals(app.getPackageName())) {
                        targetApplication = app;
                        sendCardIfReady();
                    }
                }
            });
        } catch (Throwable t) { XposedBridge.log(TAG + "target Application hook failed: " + t); }
    }

    private static void hookModel(ClassLoader loader, String className, boolean battery) {
        try {
            Class<?> c = XposedHelpers.findClass(className, loader);
            XposedBridge.hookAllConstructors(c, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    String value = describe(p.thisObject);
                    if (battery) {
                        lastBattery = value;
                        if (pendingWearPopup && isWearing(lastEar)) sendCardIfReady();
                    } else {
                        boolean wasWearing = previousWearing;
                        lastEar = value;
                        boolean wearing = isWearing(value);
                        previousWearing = wearing;
                        if (wearing && !wasWearing) {
                            pendingWearPopup = true;
                            sendCardIfReady();
                        }
                    }
                }
            });
            XposedBridge.log(TAG + "hooked model " + className);
        } catch (Throwable t) { XposedBridge.log(TAG + "model unavailable " + className + ": " + t); }
    }

    private static String describe(Object object) {
        if (object == null) return "";
        StringBuilder out = new StringBuilder();
        for (Class<?> c = object.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                try {
                    f.setAccessible(true);
                    Object v = f.get(object);
                    if (v == null || v instanceof Number || v instanceof Boolean || v instanceof String) {
                        String n = f.getName().toLowerCase(Locale.ROOT);
                        if (n.contains("left") || n.contains("right") || n.contains("case") || n.contains("battery") || n.contains("ear") || n.contains("in") || n.contains("connected")) {
                            if (out.length() > 0) out.append("  ·  ");
                            out.append(f.getName()).append('=').append(v);
                        }
                    }
                } catch (Throwable ignored) { }
            }
        }
        return out.length() == 0 ? String.valueOf(object) : out.toString();
    }

    private static void sendCardIfReady() {
        Application app = targetApplication;
        if (app == null) return;
        String battery = lastBattery;
        if (battery == null || battery.trim().isEmpty()) return;
        if (!pendingWearPopup || !isWearing(lastEar)) return;
        long now = System.currentTimeMillis();
        long previous = lastSent.get();
        if (now - previous < THROTTLE_MS || !lastSent.compareAndSet(previous, now)) return;
        try {
            Intent intent = new Intent(ACTION);
            intent.setPackage(SYSTEM_UI);
            intent.putExtra("battery", battery);
            intent.putExtra("ear", lastEar == null ? "" : lastEar);
            intent.putExtra("source", "HyperPods AAP");
            app.sendBroadcast(intent);
            pendingWearPopup = false;
        } catch (Throwable t) { XposedBridge.log(TAG + "broadcast failed: " + t); }
    }

    private static boolean isWearing(String raw) {
        if (raw == null || raw.isEmpty()) return false;
        String value = raw.toLowerCase(Locale.ROOT);
        // Only treat explicit positive in-ear/wear flags as wearing; avoid false popups on disconnect.
        return (value.contains("inear=true") || value.contains("in_ear=true")
                || value.contains("wearing=true") || value.contains("iswearing=true")
                || value.contains("wearstate=1") || value.contains("earstate=1"));
    }

    private static void hookSystemUi(ClassLoader loader) {
        try {
            XposedHelpers.findAndHookMethod(Application.class, "onCreate", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Application app = (Application) p.thisObject;
                    if (!SYSTEM_UI.equals(app.getPackageName())) return;
                    try {
                        IntentFilter filter = new IntentFilter(ACTION);
                        BroadcastReceiver receiver = new BroadcastReceiver() {
                            @Override public void onReceive(Context context, Intent intent) {
                                String battery = intent.getStringExtra("battery");
                                String ear = intent.getStringExtra("ear");
                                if (battery != null && !battery.trim().isEmpty()) showSystemCard(app, battery, ear == null ? "" : ear);
                            }
                        };
                        if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED);
                        else app.registerReceiver(receiver, filter);
                        XposedBridge.log(TAG + "SystemUI receiver registered");
                    } catch (Throwable t) { XposedBridge.log(TAG + "SystemUI receiver failed: " + t); }
                }
            });
        } catch (Throwable t) { XposedBridge.log(TAG + "SystemUI Application hook failed: " + t); }
    }

    private static void showSystemCard(Context context, String battery, String ear) {
        MAIN.post(() -> {
            WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            if (wm == null) return;
            try {
                View previousCard = activeCard;
                WindowManager previousWm = activeWindowManager;
                if (previousCard != null && previousCard.getParent() != null && previousWm != null) {
                    try { previousWm.removeView(previousCard); } catch (Throwable ignored) { }
                }
                activeCard = null;
                activeWindowManager = wm;
                LinearLayout card = new LinearLayout(context);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(context, 17), dp(context, 12), dp(context, 17), dp(context, 12));
                card.setElevation(dp(context, 18));
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(Color.rgb(25, 26, 29));
                bg.setCornerRadius(dp(context, 27));
                bg.setStroke(dp(context, 1), Color.argb(85, 255, 255, 255));
                card.setBackground(bg);

                LinearLayout heading = new LinearLayout(context);
                heading.setOrientation(LinearLayout.HORIZONTAL);
                heading.setGravity(Gravity.CENTER_VERTICAL);
                TextView glyph = new TextView(context);
                glyph.setText("◖♪◗");
                glyph.setTextColor(Color.WHITE);
                glyph.setTextSize(17);
                glyph.setGravity(Gravity.CENTER);
                glyph.setBackground(round(Color.rgb(62, 64, 70), dp(context, 13)));
                heading.addView(glyph, new LinearLayout.LayoutParams(dp(context, 42), dp(context, 42)));

                LinearLayout names = new LinearLayout(context);
                names.setOrientation(LinearLayout.VERTICAL);
                names.setPadding(dp(context, 11), 0, 0, 0);
                TextView title = new TextView(context);
                title.setText("耳机电量");
                title.setTextColor(Color.WHITE);
                title.setTextSize(15);
                title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                names.addView(title);
                TextView subtitle = new TextView(context);
                subtitle.setText("HyperPods · 已更新");
                subtitle.setTextColor(Color.rgb(164, 167, 175));
                subtitle.setTextSize(11);
                LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-2, -2);
                subLp.topMargin = dp(context, 2);
                names.addView(subtitle, subLp);
                heading.addView(names, new LinearLayout.LayoutParams(0, -2, 1f));
                card.addView(heading);

                TextView bat = new TextView(context);
                bat.setText(prettify(battery));
                bat.setTextColor(Color.rgb(238, 239, 242));
                bat.setTextSize(13);
                bat.setMaxLines(3);
                bat.setLineSpacing(dp(context, 2), 1f);
                LinearLayout.LayoutParams batLp = new LinearLayout.LayoutParams(-1, -2);
                batLp.topMargin = dp(context, 10);
                card.addView(bat, batLp);
                if (ear != null && !ear.trim().isEmpty() && !ear.equals("")) {
                    TextView earView = new TextView(context);
                    earView.setText(prettify(ear));
                    earView.setTextColor(Color.rgb(167, 171, 181));
                    earView.setTextSize(11);
                    earView.setMaxLines(2);
                    LinearLayout.LayoutParams earLp = new LinearLayout.LayoutParams(-1, -2);
                    earLp.topMargin = dp(context, 4);
                    card.addView(earView, earLp);
                }

                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    (int) (context.getResources().getDisplayMetrics().widthPixels * 0.88f),
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_STATUS_BAR_SUB_PANEL,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                lp.y = dp(context, 34);
                lp.setTitle("HyperPodsIslandLSP");
                wm.addView(card, lp);
                activeCard = card;
                card.setAlpha(0f);
                card.animate().alpha(1f).setDuration(150).start();
                card.postDelayed(() -> {
                    try {
                        if (card.getParent() != null) {
                            card.animate().alpha(0f).setDuration(130).withEndAction(() -> {
                                try { wm.removeView(card); } catch (Throwable ignored) { }
                                if (activeCard == card) activeCard = null;
                            }).start();
                        }
                    } catch (Throwable ignored) { }
                }, Math.max(0L, CARD_DURATION_MS - 130L));
            } catch (Throwable t) {
                XposedBridge.log(TAG + "SystemUI card failed: " + t);
            }
        });
    }

    private static GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private static String prettify(String raw) {
        if (raw == null) return "";
        return raw.replace("leftBattery", "左耳电量")
            .replace("rightBattery", "右耳电量")
            .replace("caseBattery", "充电盒电量")
            .replace("left_battery", "左耳电量")
            .replace("right_battery", "右耳电量")
            .replace("case_battery", "充电盒电量")
            .replace("left", "左耳")
            .replace("right", "右耳")
            .replace("case", "充电盒")
            .replace("battery", "电量")
            .replace("connected", "已连接")
            .replace("inEar", "入耳")
            .replace("=true", "：是")
            .replace("=false", "：否")
            .replace("=", "：");
    }

    private static int dp(Context c, float value) {
        return (int) (value * c.getResources().getDisplayMetrics().density + 0.5f);
    }
}
