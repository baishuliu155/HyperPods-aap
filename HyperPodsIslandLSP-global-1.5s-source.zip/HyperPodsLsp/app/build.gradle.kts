plugins { id("com.android.application") }

android {
    namespace = "moe.chenxy.hyperpods.lsp"
    compileSdk = 35
    defaultConfig {
        applicationId = "moe.chenxy.hyperpods.lsp"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    compileOnly("de.robv.android.xposed:api:82")
}
