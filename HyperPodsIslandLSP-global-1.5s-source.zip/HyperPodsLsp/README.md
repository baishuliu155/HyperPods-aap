# HyperPods Island LSP

LSPosed module prototype for HyperPods AAP 3.0.0 on HyperOS 2. It forwards battery/ear-state model updates from HyperPods to SystemUI and draws a LibrePods-inspired floating battery card above other apps for 1.5 seconds.

## Build

Open this project in Android Studio (JDK 17 or 21, Android SDK 35) or run `./gradlew assembleDebug` after adding a standard Gradle wrapper. GitHub Actions builds a debug APK on push or manual dispatch.

## Install and enable

1. Install the generated APK and activate it in LSPosed.
2. In LSPosed scope, enable **both** `moe.chenxy.hyperpods` and `com.android.systemui`.
3. Reboot, or restart SystemUI and HyperPods.
4. Connect supported earbuds and wait for HyperPods to receive a battery update.

## Notes / limitations

- This is a best-effort hook against the AAP 3.0.0 data model names and must be validated on the target ROM/device.
- The SystemUI process owns the window, so the card can appear over the launcher and other apps without requesting overlay permission from HyperPods.
- It uses `TYPE_STATUS_BAR_SUB_PANEL`, which is intended for system UI windows. Xiaomi/HyperOS releases may restrict or alter this window type; check LSPosed logs if the card does not appear.
- The module does not spoof battery values. It forwards values observed in HyperPods model objects.


## Wear-trigger behavior and limitations

The current prototype sends a global card request to SystemUI only when the hooked ear-detection model exposes an explicit positive in-ear/wearing flag. The card fades away after 1.5 seconds. The field names/semantics in HyperPods AAP 3.0.0 must be confirmed on a real device; if this build's model does not expose one of the recognized flags, no popup will appear until the detector is adapted to the actual model fields.

Enable this module for both `moe.chenxy.hyperpods` and `com.android.systemui` in LSPosed. Reboot or force-stop both processes after enabling. SystemUI's overlay window type is privileged and behavior may vary by HyperOS version. This source has not been compiled or device-tested in this environment.
